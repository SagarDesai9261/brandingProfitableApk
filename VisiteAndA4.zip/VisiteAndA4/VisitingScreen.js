import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import React, { useEffect, useState } from 'react';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import CardsCarousal from './CardsCarousal';
import axios from 'axios';

const VisitingScreen = ({ navigation }) => {
    const [counts, setCounts] = useState([]);
    const [loader, setLoader] = useState(true);

    const fetchData = async () => {
        try {
            const response = await axios.get("https://brandingprofitable-uat-89aac59cca6c.herokuapp.com/visiting/visiting");
            const data = response.data.data ? response.data.data : [];
            setCounts(data);
            if (response.data.data.length === 0) {
                showToastWithGravity("something went wrong...");
                navigation.goBack();
            }
            setLoader(false);
        } catch (error) {
            setLoader(false);
            console.error("error in fetch data", error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handlePress = (frame) => {
        navigation.navigate('CardsForm', { dataHTML: frame.visiting_data });
    };

    const showToastWithGravity = (data) => {
      ToastAndroid.showWithGravityAndOffset(
        data,
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
        0,
        50,
      );
    };

    return (
        <LinearGradient colors={['#050505', '#1A2A3D']} style={styles.container}>
            <View style={styles.headerContainer}>
                <TouchableOpacity onPress={() => { navigation.goBack() }}>
                    <Icon name="angle-left" size={30} color={"white"} />
                </TouchableOpacity>
                <Text style={styles.headerText}>E Visiting Card</Text>
            </View>
            <View style={styles.contentContainer}>
                {loader ? (
                    <ActivityIndicator color={'white'} />
                ) : (
                    <CardsCarousal counts={counts} handlePress={handlePress} />
                )}
            </View>
        </LinearGradient>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    headerContainer: {
        height: 50,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
    },
    headerText: {
        fontSize: 16,
        color: 'white',
        fontFamily: 'Manrope-Bold',
        marginLeft: 20,
    },
    contentContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 20,
    },
});

export default VisitingScreen;
